function [betaTU_vec] = FMTU(X,Y,Z,clusterStruct,piStar)

G = max(clusterStruct);
k = size(Z,2);

betaTU_vec = zeros(G,1);
for g = 1 : G
    betaU_k_vec = zeros(k,1);
    X_temp = X(clusterStruct==g);
    Y_temp = Y(clusterStruct==g);
    Z_temp = Z(clusterStruct==g,:);
    for iZ = 1 : k
        betaU_k_vec(iZ) = truncated_unbiased_iv(X_temp,Y_temp,...
            Z_temp(:,iZ),piStar);
    end
    betaTU_vec(g) = mean(betaU_k_vec);
end