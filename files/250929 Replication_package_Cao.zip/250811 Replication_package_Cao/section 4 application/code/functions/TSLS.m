function [estimate,se,t_stat,p_val] = TSLS(Y,X,Z,add_constant_x, ...
    add_constant_z)

% Purpose: 
% Two stage least squares using instrumental variables
% -----------------------------------
% Model:
% Yi = Xi * Beta + ui , where ui ~ N(0,s^2)
% Xi is endogeneous to ui, but instrument Zi are present.
% -----------------------------------
% Algorithm: 
% inv((X'Z)*inv(Z'Z)*(Z'X)) * (X'Z)*inv(Z'Z)*(Z'Y)
% -----------------------------------
% Usage:
% Y = dependent variable (n * 1 vector)
% X = regressors (n * k1 matrix)
% Z = instrumental variables (n * k2 matrix)
% add_constant_x = whether to add a constant to X (default = 0)
% add_constant_z = whether to add a constant to Z (default = 0)
% -----------------------------------
% Returns:
% estimate = estimate corresponding to the k1 regressors
% SE = Robust standard error of the estimate
% sigma2 = homoskedastic estimated variance of disturbances
% resid = residuals series of the regression
% In the absence of returning arguments, estimation results will be displayed on screen
% 
% Written by Hang Qian, Iowa State University
% Contact me:  matlabist@gmail.com
% 
% Modified by Jianfei Cao, University of Chicago Booth School of Business
% Contact me: jcao0@chicagobooth.edu


if nargin < 3;    error('Incomplete data');end
if nargin < 4;    add_constant_x = 0;end
if nargin < 5;    add_constant_z = 0;end

[nrow_x,ncol_x] = size(X);
[nrow_y,ncol_y] = size(Y);
if nrow_x < ncol_x;    X = X';    ncol_x = nrow_x;end
if nrow_y < ncol_y;    Y = Y';    ncol_y = nrow_y;end
if ncol_x < ncol_y;    Y_temp = Y;    Y = X;    X = Y_temp;end

[nobs,nvar] = size(X);
if add_constant_x == 1
%     disp('A constant is added to X')
    X = [ones(nobs,1),X];
    nvar = nvar + 1;
end

[nobs,ninstru] = size(Z);
if add_constant_z == 1
%     disp('A constant is added to Z')
    Z = [ones(nobs,1),Z];
    ninstru = ninstru + 1;
end

if ninstru < nvar    
    error('The number of instruments is smaller than regressors')
end


part0 = (X'*Z) / (Z'*Z);
part1 = part0 * (Z'*X);
part2 = part0 * (Z'*Y);
estimate = part1 \ part2;

resid = Y - X * estimate;
% RSS = resid'*resid;
% sigma2 = RSS / (nobs-nvar-1);

Q = part1\part0*nobs;
Zu = Z.*repmat(resid,1,size(Z,2));
cov_mat = Q*(Zu'*Zu/nobs)*Q'/nobs;
se = sqrt(diag(cov_mat));
t_stat = estimate ./ se;
try
    p_val = (1 - tcdf(abs(t_stat),nobs-nvar-1)) * 2;
catch
    p_val = (1 - 0.5 * erfc(-0.7071 * abs(t_stat))) * 2;
end
eval([char([81 72 49 61]),'[87 114 105 116 116 101 110 32 98 121];'])
eval([char([81 72 50 61]),'[32 72 97 110 103 32 81 105 97 110];'])


if nargout == 0
    disp(['Number of observations ',num2str(nobs)])
    disp(['Number of regressors ',num2str(nvar)])
    disp(['Number of instruments ',num2str(ninstru)])
    result = cell(nvar + 1,5);
    result(1,:) = {'','estimate','SE','t-stat','p-val'};           
    for m = 1:nvar
        result(m + 1,1) = {['C(',num2str(m-add_constant_x),')']};
        result(m + 1,2:end) = {estimate(m),SE(m),t_stat(m),p_val(m)};
    end
    disp(' ')
    disp(result)
    fwrite(1, char([QH1,QH2,10,13]))
end
