function [S] = hac_iv(X,U,V,varargin)
%HAC Heteroskedasticity and Autocorrelation Consistent covariance matrix
%   estimation
%
%   [S] = HAC(X,U) Newey-West estimator with 4*(T/100)^(1/4) lags
%   Values:
%       S - a matrix of covariance estimate
%   Arguments:
%       X - matrix of regressors
%       u - regression residuals
%  
%   [S] = HAC(X,U,'PARAM1',val1,'PARAM2',val2,...) 
%   Parameters:
%       'Method' - specifies method of estimator.'NW' - Newey-West/Bartlett
%           kernel (the default). 'QS' - Quadratic Spectral kernel. 'VAR' -
%           VARHAC as in Den Haan and Levin (1997).
%       'Bandwidth' - tuning parameter, mainly for NW method. 'truncate' - 
%           use 4*(T/100)^(1/4) lags (the default). 'optimal' - use method 
%           in Newey and West (1994) to determine optimal bandwidth. 'all' 
%           - use all lags. For QS method, bandwidth is determined by 
%           method specified in Andrews and Monahan (1992). For VARHAC 
%           method, number of lags included is determined by BIC. One can
%           also input an number to specify a bandwidth.
%       'Prewhite' - whether to prewhiten. 0 is not prewhitening (the
%           default).
%       'Constant' - specifies whether a constant term is included in X in
%           order to choose weight w. The default is false. Please put
%           constant term in the first column of X.

[T,p] = size(X);
% [size(X);size(U);size(V)]
Xu = [X.*repmat(U,1,p) X.*repmat(V,1,p)];

% initialization
[method,bandwidth,prewhite,cons] = process_options(varargin,...
    'Method','NW','Bandwidth','truncate','Prewhite',false,...
    'Constant',false);
w = ones(p,1);

if cons
    w(1) = 0;
end

if prewhite
    A = (Xu(2:end,:)'*Xu(1:end-1,:))/(Xu(1:end-1,:)'*Xu(1:end-1,:));
    Xu = (Xu(2:end,:)'-A*Xu(1:end-1,:)')';
    T = T-1;
end


% Newey-West estimator
if strcmp(method,'NW')
    % bandwidth selection
    if isnumeric(bandwidth) % bandwidth specified by user
        m = bandwidth;
    end
    if strcmp(bandwidth,'truncate') % truncate m = 4*(T/100)^(1/4)
        m = floor(4*(T/100)^(1/4));
    end
    if strcmp(bandwidth,'optimal') % optimal gamma
        s1 = 0;
        s0 = w'*(Xu'*Xu/T)*w;
        for i = 1 : floor(12*(T/100)^(2/9)) % tuning parameter
            Gamma_i = Xu(1+i:end,:)'*Xu(1:end-i,:)/T;
            s1 = s1+2*i*(w'*Gamma_i*w);
            s0 = s0+2*(w'*Gamma_i*w);
        end
        gamma_BT = 1.1447*((s1/s0)^2)^(1/3);
        m = floor(gamma_BT*T^(1/3));
    end
    if strcmp(bandwidth,'all') % all lags
        m = T-1;
    end
    
    % estimation
    S = Xu'*Xu/T; % Gamma_0
    for j = 1 : m
        Gamma_j = Xu(1+j:end,:)'*Xu(1:end-j,:)/T;
        k_j = 1-j/(m+1);
        S = S+k_j*(Gamma_j+Gamma_j');
    end
end


% Quadratic Spectral
if strcmp(method,'QS')
    % bandwidth selection
    if isnumeric(bandwidth) % bandwidth specified by user
        m = bandwidth;
    else
        % optimal bandwidth
        s2 = 0;
        s0 = 0;
        for i = 1 : p
            [rho_i,sigma2_i] = arp(Xu(:,i),1);
            s2 = s2+w(i)*4*rho_i^2*sigma2_i^2/(1-rho_i)^8;
            s0 = s0+w(i)*sigma2_i^2/(1-rho_i)^4;
        end
        gamma_QS = 1.3221*(s2/s0)^(1/5);
        m = gamma_QS*T^(1/5);
    end
    
    % estimation
    S = Xu'*Xu/T; % Gamma_0
    for j = 1 : T-1
        x_j = j/m;
        z_j = 6*pi*x_j/5;
        k_j = 3/z_j^2*(sin(z_j)/z_j-cos(z_j)); % QS kernel
        Gamma_j = Xu(1+j:end,:)'*Xu(1:end-j,:)/T;
        S = S+k_j*(Gamma_j+Gamma_j');
    end
end


% VARHAC by BIC
% (incomplete)


if prewhite
    S = ((eye(p)-A)\S)/((eye(p)-A)');
end



