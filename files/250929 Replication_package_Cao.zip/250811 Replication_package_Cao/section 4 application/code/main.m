

clear

tic 

addpath('functions')
addpath('functions/borders');


%% Input
rng(7) % fix seed
data_input = csvread("../temp/table8_latlong.csv",1);
Y = data_input(:,3); % outcome
X = data_input(:,4); % endogenous variable
Z = data_input(:,5); % instrument
lat_city = data_input(:,6);
lon_city = data_input(:,7);
coords = [lat_city,lon_city];
n = length(Y);
gray_color = [50 50 50]/255*3;


%% Replicate Harari (2020) Table 8
% first stage - OLS
[estimate_vec,se_vec] = TSLS(X,Z,Z,1,1);
estimate_FS = estimate_vec(2);
se_FS = se_vec(2);
tstat_FS = estimate_FS/se_FS;
Z_mat = [ones(n,1),Z];
resid_FS = X-Z_mat*estimate_vec;
iXX = inv(Z_mat'*Z_mat);

% 2SLS with White s.e.
[estimate_vec,se_vec,tstat_vec,p_value_vec] = TSLS(Y,X,Z,1,1);
estimate_2SLS = estimate_vec(2);
se_2SLS = se_vec(2);
tstat_2SLS = tstat_vec(2);
p_value_2SLS = p_value_vec(2);


%% main loop
nClustering = 2;
estimate_FMTU = zeros(nClustering,1);
se_FMTU = zeros(nClustering,1);
tstat_FMTU = zeros(nClustering,1);
p_value_FMTU = zeros(nClustering,1);
G = zeros(nClustering,1);

for iClustering = 1:2

%% Clustering Structure 
if iClustering == 1
    % Perform k-medoids clustering
    G(iClustering) = 8; % devide cites into G groups according to geographic locations
    membership = kmedoids(coords,G(iClustering));
else
     % cluster by state
    state_id = unique(data_input(:,2));
    membership = zeros(n,1);
    for ii = 1 : n
        membership(ii) = sum(data_input(ii,2)>=state_id);
    end
    G(iClustering) = length(unique(membership));
end 


figure(iClustering)
%% Draw district border
district_list = dir('../temp');
hold on 
for i_district = 1 : length(district_list)
    if startsWith(district_list(i_district).name,'fid')
        fid_i_border = csvread(['../temp/',...
            district_list(i_district).name]);
        district_lat = fid_i_border(:,2);
        district_lon = fid_i_border(:,1);
        plot(district_lon,district_lat,'k','linewidth',.5,...
            'Color', gray_color)
    end
end
hold off


%% Draw India border
[lat_border,lon_border] = borders('india');
hold on 
plot(lon_border,lat_border,'color',gray_color/2) % draw borders of India
hold off


%% Draw clustering
hold on
for g = 1 : G(iClustering)
    scatter(lon_city(membership==g),lat_city(membership==g),30,'^','filled');
end
hold off
axis image % correct aspect-ratio
xlabel('Longitude(\circ)')
ylabel('Latitude(\circ)')
fontsize(22,"points")
saveas(gcf,['../output/india_city_clustering',num2str(iClustering)],'pdf');


%% FMTU
betaTU_vec = FMTU(X-mean(X),Y-mean(Y),Z-mean(Z),membership,0);
betaTU_vec(isnan(betaTU_vec)) = [];
betaTU_vec(betaTU_vec==inf) = [];
G(iClustering) = length(betaTU_vec);

estimate_FMTU(iClustering) = mean(betaTU_vec);
se_FMTU(iClustering) = std(betaTU_vec)/sqrt(G(iClustering));
tstat_FMTU(iClustering) = estimate_FMTU(iClustering)/se_FMTU(iClustering);
p_value_FMTU(iClustering) = (1 - tcdf(abs(tstat_FMTU(iClustering)),G(iClustering)-1)) * 2;


%% Test for normality
X_res = X-mean(X);
Y_res = Y-mean(Y);
Z_res = Z-mean(Z);
p = numel(unique(membership));
k = size(X_res,2);
pmiss = 0;
pibeta_temp = zeros(p,k);
pi_temp = zeros(p,k);
for ii = 1:p
    fii = membership == ii;
    if sum(fii) > k
        pibeta_temp(ii,:) = (Z_res(fii,:)'*Z_res(fii,:))\...
            (Z_res(fii,:)'*Y_res(fii,:));
        pi_temp(ii,:) = (Z_res(fii,:)'*Z_res(fii,:))\...
            (Z_res(fii,:)'*X_res(fii,:));
    else
        pibeta_temp(ii,:) = NaN*ones(1,k);
        pi_temp(ii,:) = NaN*ones(1,k);
        pmiss = pmiss+1;
    end
end
pibeta_temp(isnan(pibeta_temp)) = [];
pi_temp(isnan(pi_temp)) = [];

% normalization
pibeta_vec = (pibeta_temp-mean(pibeta_temp))/std(pibeta_temp);
pi_vec = (pi_temp-mean(pi_temp))/std(pi_temp);

% test whether normality is rejected for both pi and pi*beta
[H,P,KSSTAT] = kstest(pibeta_vec);
[H,P,KSSTAT] = kstest(pi_vec);

end


%% Output to latex
f = fopen('../output/table8_replication.tex','w');
fprintf(f, '$\\Delta$ Potential normalized shape & %1.4f \\\\\n', ...
    estimate_FS);
fprintf(f, ' & (%1.4f) \\\\\n', ...
    se_FS);
fprintf(f, '$\\Delta$ Normalized shape & & & %1.1f & %1.1f & %1.1f\\\\\n', ...
    estimate_2SLS, estimate_FMTU(1), estimate_FMTU(2));
fprintf(f, ' & & & (%1.2f) & (%1.2f) & (%1.2f)\\\\ \n', ...
    se_2SLS, se_FMTU(1),se_FMTU(2));
fprintf(f, ' $t$-stat & %1.3f & & %1.3f & %1.3f & %1.3f\\\\ \n', ...
    tstat_FS, tstat_2SLS, tstat_FMTU(1), tstat_FMTU(2)); 
fprintf(f, ' $p$-value & & & %1.3f & %1.3f & %1.3f\\\\ \n', p_value_2SLS, ...
    p_value_FMTU(1),p_value_FMTU(2)); 
fprintf(f, '\\\\\n');
fprintf(f, ' number of groups & & & & %d & %d\\\\ \n', G(1),G(2)); 
% fprintf(f, '\\\\\n');
fprintf(f, 'Observations & %d & & %d & %d & %d ', n, n, n, n);
fclose(f);

toc




















