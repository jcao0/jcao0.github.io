import os

f0 = open('../input/India_Districts_ADM2_GADM.kml','r')

for line in f0:
	# find the district ID "FID"
	if '"FID">' in line:
		fid = line[line.find('"FID">')+6:line.find('</SimpleData')]
		filename = ('../temp/fid'+str(fid)+'_border.csv')
		try:
			os.remove(filename)
		except:
			pass
		f = open(filename,'a')
	# copy coordinates to a separate csv file in the ../temp folder
	if 'coordinates' in line:
		coordinates_string = line[line.find('<coordinates>')+13:line.find('</coordinates>')]
		coordinates_list = coordinates_string.split(' ')
		for coord in coordinates_list:
			f.write(coord+'\n')
		f.close()

f0.close()

import platform
print(platform.python_version())