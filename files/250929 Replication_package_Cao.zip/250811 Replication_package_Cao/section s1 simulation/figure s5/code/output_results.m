

%% CCE
size_cce = mean(abs(beta2SLS_vec./seCCE_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1))
powerCurve_cce = mean(abs((repmat(beta2SLS_vec,1,nAltPowerCurve)+...
    repmat(altPowerCurve,nSim,1))./repmat(seCCE_vec,1,...
    nAltPowerCurve)) >tinv(1-sigLevel/2,...
    max(clusterStruct)-1));


%% FMTU
test_fmtu = abs(betaTU_vec./seTU_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1);
size_fmtu = mean(test_fmtu)

powerCurve_fmtu = mean(testTU_powerCurve);


%% FMUT with other truncation parameters
powerCurve_fmut1 = mean(testU1_powerCurve);
powerCurve_fmut2 = mean(testU2_powerCurve);


%% plot all power curves

p = plot(altPowerCurve,powerCurve_cce,':',...
    altPowerCurve,powerCurve_fmut1,'--',...
    altPowerCurve,powerCurve_fmtu,'-',...
    altPowerCurve,powerCurve_fmut2,'-.');
p(1).LineWidth = 2;
p(2).LineWidth = 2;
p(3).LineWidth = 2;
p(4).LineWidth = 2;
hold on
plot([0,0],[0,1],'--k')
hold off
lgd = legend('CCE','FMTU, \pi^*=-.15','FMTU, \pi^*=-.2','FMTU, \pi^*=-.25','location','eastoutside');
% lgd.FontSize = 7;
xlim([-altBound,altBound])
if imbalance == 0
    title(['||\pi||_2=',num2str(norm(pi)),', balanced groups'])
elseif imbalance == 1
    title(['||\pi||_2=',num2str(norm(pi)),', imbalanced groups'])
end
fontsize(16 ,"points")
saveas(gcf,'../output/compare_truncation_parameters.pdf')


