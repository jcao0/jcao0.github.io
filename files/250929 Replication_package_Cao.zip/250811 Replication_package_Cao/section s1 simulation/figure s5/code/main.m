

clear
tic


%% LOAD SETTINGS
nSim = 1000;
k = 5;
firstStageStrength = 0.1;
imbalance = 1;
pi = firstStageStrength*ones(k,1)/sqrt(k);
testMode = 0;


%% INITIALIZATION
initialization


%% MAIN LOOP
WaitMessage = parfor_wait(nSim);
parfor iSim = 1 : nSim

WaitMessage.Send

rng(iSim)


%% DGP

% independent groups
Sigma_uv = [1 rhoUV ; rhoUV 1];
CSigma_uv = chol(Sigma_uv);
err = ar1_cluster(n,2,rhoTime,clusterStruct)*CSigma_uv;

U = err(:,1);
V = err(:,2);
Y = Z*pi*beta0+U;
X = Z*pi+V;


%% White
piHat = (Z'*Z)\(Z'*X);
beta2SLS = (piHat'*Z'*X)\(piHat'*Z'*Y);
resid = Y-X*beta2SLS;
iZX = (piHat'*(Z'*Z)*piHat)\piHat';
sctmp = cluster_se(Z,resid,iZX,(1:n)');

beta2SLS_vec(iSim) = beta2SLS;
piHat_mat(iSim,:) = piHat';
seWhite_vec(iSim) = sctmp(1);


%% CCE
sctmp = cluster_se(Z,resid,iZX,clusterStruct);

seCCE_vec(iSim) = sctmp(1);


%% FMTU
piStar = -.2;
betaU_g_vec = FMTU(X,Y,Z,clusterStruct,piStar);
betaTU_vec(iSim) = mean(betaU_g_vec);
seTU_vec(iSim) = std(betaU_g_vec)/sqrt(G);

% power curve
testTU_powerCurve_temp = zeros(1,nAltPowerCurve);
for iAlt = 1 : nAltPowerCurve
    
    Y_alt = Y+Z*pi*altPowerCurve(iAlt);
    betaU_g_vec = FMTU(X,Y_alt,Z,clusterStruct,piStar);
    
    testTU_powerCurve_temp(iAlt) = abs(mean(betaU_g_vec)/...
        (std(betaU_g_vec)/sqrt(G))) > tinv(1-sigLevel/2,...
        max(clusterStruct)-1);
  
end
testTU_powerCurve(iSim,:) = testTU_powerCurve_temp;


%% FMUT with another pi*
piStar = -.15;

% power curve
testU_powerCurve_temp = zeros(1,nAltPowerCurve);
for iAlt = 1 : nAltPowerCurve
    
    Y_alt = Y+Z*pi*altPowerCurve(iAlt);
    betaU_g_vec = FMTU(X,Y_alt,Z,clusterStruct,piStar);
    
    testU_powerCurve_temp(iAlt) = abs(mean(betaU_g_vec)/...
        (std(betaU_g_vec)/sqrt(G))) > tinv(1-sigLevel/2,...
        max(clusterStruct)-1);
  
end
testU1_powerCurve(iSim,:) = testU_powerCurve_temp;


%% FMUT with another pi*
piStar = -.25;

% power curve
testU_powerCurve_temp = zeros(1,nAltPowerCurve);
for iAlt = 1 : nAltPowerCurve
    
    Y_alt = Y+Z*pi*altPowerCurve(iAlt);
    betaU_g_vec = FMTU(X,Y_alt,Z,clusterStruct,piStar);
    
    testU_powerCurve_temp(iAlt) = abs(mean(betaU_g_vec)/...
        (std(betaU_g_vec)/sqrt(G))) > tinv(1-sigLevel/2,...
        max(clusterStruct)-1);
  
end
testU2_powerCurve(iSim,:) = testU_powerCurve_temp;



end

save('../temp/all_results.mat');


%% OUTPUT RESULTS
output_results


toc
