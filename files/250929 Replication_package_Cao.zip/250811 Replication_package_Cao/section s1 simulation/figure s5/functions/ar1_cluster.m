function [a] = ar1_cluster(n,k,rho,clusterStruct)
% generate k independent AR(1) process of length n with some clustering structure

a = zeros(n,k);
G = max(clusterStruct);

for g = 1 : G
    ind_g = (clusterStruct == g);
    n_g = sum(ind_g);
    a_g = zeros(n_g,k);
    a_g(1,:) = randn(1,k);
    for ii = 2 : n_g
        a_g(ii,:) = rho*a_g(ii-1,:)+sqrt(1-rho^2)*randn(1,k);
    end
    a(ind_g,:) = a_g;
end



