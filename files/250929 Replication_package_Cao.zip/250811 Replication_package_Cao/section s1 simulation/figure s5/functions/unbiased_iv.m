function [betaU] = unbiased_iv(X,Y,Z)

n = size(Z,1);

gammaHat = (Z'*Z)\(Z'*Y);
piHat = (Z'*Z)\(Z'*X);

U_hat = Y-Z*gammaHat;
V_hat = X-Z*piHat;
OmegaHat = hac_iv(Z,U_hat,V_hat);
Qzz = Z'*Z/n;
SigmaHat = kron(eye(2),inv(Qzz))*OmegaHat*kron(eye(2),inv(Qzz))/n;

delta = gammaHat-piHat*SigmaHat(1,2)/SigmaHat(2,2);
sigma2 = sqrt(SigmaHat(2,2));
tau = (1-normcdf(piHat/sigma2))/normpdf(piHat/sigma2)/sigma2;

% set tau to 0 when tau=0/0, since 1-normcdf shrink faster than normpdf
if isnan(tau)
    tau = 0; 
end

betaU = delta*tau+SigmaHat(1,2)/SigmaHat(2,2);
