

%% CCE
size_cce = mean(abs(beta2SLS_vec./seCCE_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1))
powerCurve_cce = mean(abs((repmat(beta2SLS_vec,1,nAltPowerCurve)+...
    repmat(altPowerCurve,nSim,1))./repmat(seCCE_vec,1,...
    nAltPowerCurve)) >tinv(1-sigLevel/2,...
    max(clusterStruct)-1));


%% FM
test_im = abs(betaIM_vec./seIM_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1);
size_im = mean(test_im)

powerCurve_im = mean(abs((repmat(betaIM_vec,1,nAltPowerCurve)+...
    repmat(altPowerCurve,nSim,1))./repmat(seIM_vec,1,...
    nAltPowerCurve)) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1));


%% FMU
powerCurve_fmu = mean(testU_powerCurve);


%% FMTU
test_fmtu = abs(betaTU_vec./seTU_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1);
size_fmtu = mean(test_fmtu)

powerCurve_fmtu = mean(testTU_powerCurve);


%% plot all power curves

p = plot(altPowerCurve,powerCurve_cce,':',...
    altPowerCurve,powerCurve_im,'--',...
    altPowerCurve,powerCurve_fmu,'-.',...
    altPowerCurve,powerCurve_fmtu,'-');
p(1).LineWidth = 2;
p(2).LineWidth = 2;
p(3).LineWidth = 2;
p(4).LineWidth = 2;
hold on
plot([0,0],[0,1],'--k')
hold off
lgd = legend('CCE','FM','FMU','FMTU','location','eastoutside');
xlim([-altBound,altBound])
if imbalance == 0
    title(['||\pi||_2=',num2str(norm(pi)),', balanced groups'])
elseif imbalance == 1
    title(['||\pi||_2=',num2str(norm(pi)),', imbalanced groups'])
end
fontsize(16 ,"points")
saveas(gcf,'../output/compare_FM_methods.pdf')


