

clear
tic


%% LOAD SETTINGS
nSim = 1000;
k = 10;
testMode = 0;

firstStageStrength_vec = [.5,.1];

for i_pi = 1 : 2
for imbalance = 0 : 1

pi = firstStageStrength_vec(i_pi)*ones(k,1)/sqrt(k);

%% INITIALIZATION
initialization


%% MAIN LOOP
WaitMessage = parfor_wait(nSim);
parfor iSim = 1 : nSim

WaitMessage.Send

rng(iSim)


%% DGP

% independent groups
Sigma_uv = [1 rhoUV ; rhoUV 1];
CSigma_uv = chol(Sigma_uv);
err = ar1_cluster(n,2,rhoTime,clusterStruct)*CSigma_uv;

U = err(:,1);
V = err(:,2);
Y = Z*pi*beta0+U;
X = Z*pi+V;


%% CCE
piHat = (Z'*Z)\(Z'*X);
beta2SLS = (piHat'*Z'*X)\(piHat'*Z'*Y);
resid = Y-X*beta2SLS;
iZX = (piHat'*(Z'*Z)*piHat)\piHat';
beta2SLS_vec(iSim) = beta2SLS;
sctmp = cluster_se(Z,resid,iZX,clusterStruct);
seCCE_vec(iSim) = sctmp(1);


%% Anderson-Rubin test
gammaHat = (Z'*Z)\(Z'*Y);
resid_ar = Y-Z*gammaHat;
ZpZinv = inv(Z'*Z);
[~,vcluster,~] = cluster_se(Z,resid_ar,ZpZinv,clusterStruct);

gammaHat_mat(iSim,:) = gammaHat';
vcluster_mat(:,:,iSim) = vcluster;


%% FMTU
piStar = -.2;
betaU_g_vec = FMTU(X,Y,Z,clusterStruct,piStar);
betaTU_vec(iSim) = mean(betaU_g_vec);
seTU_vec(iSim) = std(betaU_g_vec)/sqrt(G);

% power curve
testTU_powerCurve_temp = zeros(1,nAltPowerCurve);
for iAlt = 1 : nAltPowerCurve
    
    Y_alt = Y+Z*pi*altPowerCurve(iAlt);
    betaU_g_vec = FMTU(X,Y_alt,Z,clusterStruct,piStar);
    
    testTU_powerCurve_temp(iAlt) = abs(mean(betaU_g_vec)/...
        (std(betaU_g_vec)/sqrt(G))) > tinv(1-sigLevel/2,...
        max(clusterStruct)-1);
  
end
testTU_powerCurve(iSim,:) = testTU_powerCurve_temp;


end


%% OUTPUT RESULTS
subplot(2,2,(i_pi-1)*2+imbalance+1)
output_results

save(['../temp/results_',num2str((i_pi-1)*2+imbalance+1),'.mat']);

end
end

%% plot configuration 
x0=10;
y0=10;
width=800;
height=1000;
set(gcf,'position',[x0,y0,width,height])
% saveas(gcf,['../output/power_curves_4panels_k',num2str(k)])
saveas(gcf,['../output/power_curves_4panels_k',num2str(k),'.pdf'])
close(gcf)


%% GENERATE TABLE FOR PAPER USE 
generate_table


toc
