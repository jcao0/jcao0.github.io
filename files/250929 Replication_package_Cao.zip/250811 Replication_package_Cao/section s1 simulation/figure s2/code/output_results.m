

%% CCE
size_cce = mean(abs(beta2SLS_vec./seCCE_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1))
powerCurve_cce = mean(abs((repmat(beta2SLS_vec,1,nAltPowerCurve)+...
    repmat(altPowerCurve,nSim,1))./repmat(seCCE_vec,1,...
    nAltPowerCurve)) >tinv(1-sigLevel/2,...
    max(clusterStruct)-1));


%% AR
test_ar = zeros(nSim,1);
test_ar_powerCurve = zeros(nSim,nAltPowerCurve);
parfor iSim = 1 : nSim
    
    % size
    gammaHat = gammaHat_mat(iSim,:)';
    vcluster = vcluster_mat(:,:,iSim);
    AR_stat = gammaHat'/vcluster*gammaHat;
    test_ar(iSim) = AR_stat > (G*k/(G-k)*finv(1-sigLevel,k,G-k));
    
    % power
    for iAlt = 1 : nAltPowerCurve
        gammaHat_alt = gammaHat+pi*altPowerCurve(iAlt);
        AR_stat = gammaHat_alt'/vcluster*gammaHat_alt;
        test_ar_powerCurve(iSim,iAlt) = AR_stat > (G*k/(G-k)*...
            finv(1-sigLevel,k,G-k));
    end
    
end
size_ar = mean(test_ar)
powerCurve_ar = mean(test_ar_powerCurve);


%% FMTU
test_fmtu = abs(betaTU_vec./seTU_vec) > tinv(1-sigLevel/2,...
    max(clusterStruct)-1);
size_fmtu = mean(test_fmtu)

powerCurve_fmtu = mean(testTU_powerCurve);


%% plot all power curves

p = plot(altPowerCurve,powerCurve_cce,'--',...
    altPowerCurve,powerCurve_ar,'-.',...
    altPowerCurve,powerCurve_fmtu,'-');
p(1).LineWidth = 1.5;
p(2).LineWidth = 1.5;
p(3).LineWidth = 1.5;
hold on
plot([0,0],[0,1],'--k')
hold off
lgd = legend('CCE','AR-CCE','FMTU','location','SouthEast');
lgd.FontSize = 7;
xlim([-altBound,altBound])
if imbalance == 0
    title(['||\pi||_2=',num2str(norm(pi)),', balanced groups'])
elseif imbalance == 1
    title(['||\pi||_2=',num2str(norm(pi)),', imbalanced groups'])
end

