
%% parameters 
rng(60637)
restoredefaultpath % delete paths to avoid conflict
addpath('../functions')

n = 900;
G = 30;
beta0 = 0;
sigLevel = .05;
rhoTime = .3; % inter-temporal correlation
rhoUV = .5; % endogeneity strength


%% Clustering structure
if imbalance == 0
    clusterStruct = kron((1:30)',ones(30,1));
elseif imbalance == 1
    clusterStruct = [kron((1:5)',ones(90,1));kron((6:30)',ones(18,1))];
end


%% covariance matrices
Sigma = toeplitz(rhoTime.^(0:n-1));
CSigma = chol(Sigma);


%% Draw one realization of design variables. Condition on Z
% independent groups
Z = ar1_cluster(n,k,rhoTime,clusterStruct);


%% alternatives for power curves
beta2SLS_vec_temp = zeros(nSim,1);
gammaHat_vec_temp = zeros(nSim,k);
piHat_vec_temp = zeros(nSim,k);
parfor iSim = 1 : nSim
    
rng(iSim)

% DGP
err = CSigma'*mvnrnd([0 0],[1 rhoTime ; rhoTime 1],n);
U = err(:,1);
V = err(:,2);
Y = Z*pi*beta0+U;
X = Z*pi+V;

% 2SLS estimator
gammaHat = (Z'*Z)\(Z'*Y);
piHat = (Z'*Z)\(Z'*X);
beta2SLS_vec_temp(iSim) = (piHat'*Z'*X)\(piHat'*Z'*Y);

gammaHat_vec_temp(iSim,:) = gammaHat';
piHat_vec_temp(iSim,:) = piHat';

end

% use 10*median absolute deviation as the bound for power curve
altBound = 10*median(abs(beta2SLS_vec_temp));
decimalPlace = log(altBound)/log(10);
decimalShift = 10^floor(decimalPlace);
altBound = ceil(altBound/decimalShift)*decimalShift;

if testMode == 0
    altPowerCurve = linspace(-altBound,altBound,101);
else
    altPowerCurve = linspace(-altBound,altBound,15);
end
nAltPowerCurve = numel(altPowerCurve);

% true covariance matrix for [gammaHat,piHat]
Sigma_psi = cov([gammaHat_vec_temp,piHat_vec_temp]); 


%% define result matrices

% White
beta2SLS_vec = zeros(nSim,1);
seWhite_vec = zeros(nSim,1);
piHat_mat = zeros(nSim,k);

% CCE
seCCE_vec = zeros(nSim,1);

% AR
gammaHat_mat = zeros(nSim,k);
vcluster_mat = zeros(k,k,nSim);

% IM
betaIM_vec = zeros(nSim,1);
seIM_vec = zeros(nSim,1);

%FMU
testU_powerCurve = zeros(nSim,nAltPowerCurve);

% FMTU
betaU_vec = zeros(nSim,1);
betaTU_vec = zeros(nSim,1);
seTU_vec = zeros(nSim,1);
testTU_powerCurve = zeros(nSim,nAltPowerCurve);

% FMTU with other truncation parameters
testTU1_powerCurve = zeros(nSim,nAltPowerCurve);
testTU2_powerCurve = zeros(nSim,nAltPowerCurve);

