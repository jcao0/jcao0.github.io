
%% output median+MAD+size
resultsTable = zeros(6);

% pi = .5, balanced groups
load('../temp/results_1.mat')
resultsTable(1,1:3) = [median(beta2SLS_vec),median(...
    abs(beta2SLS_vec)),size_cce];
resultsTable(2,3) = size_ar;
resultsTable(3,1:3) = [median(betaTU_vec),median(...
    abs(betaTU_vec)),size_fmtu];

% pi = .5, imbalanced groups
load('../temp/results_2.mat')
resultsTable(1,4:6) = [median(beta2SLS_vec),median(...
    abs(beta2SLS_vec)),size_cce];
resultsTable(2,6) = size_ar;
resultsTable(3,4:6) = [median(betaTU_vec),median(...
    abs(betaTU_vec)),size_fmtu];

% pi = .1, balanced groups
load('../temp/results_3.mat')
resultsTable(4,1:3) = [median(beta2SLS_vec),median(...
    abs(beta2SLS_vec)),size_cce];
resultsTable(5,3) = size_ar;
resultsTable(6,1:3) = [median(betaTU_vec),median(...
    abs(betaTU_vec)),size_fmtu];

% pi = .1, imbalanced groups
load('../temp/results_4.mat')
resultsTable(4,4:6) = [median(beta2SLS_vec),median(...
    abs(beta2SLS_vec)),size_cce];
resultsTable(5,6) = size_ar;
resultsTable(6,4:6) = [median(betaTU_vec),median(...
    abs(betaTU_vec)),size_fmtu];

% resultsTable


%% write to tex 
f = fopen(['../output/simulation_k',num2str(k),'.tex'],'w');
fprintf(f,'$k=%d$ & $\\Vert\\pi\\Vert_2=0.5$ & CCE &',k);
fprintf(f,' %1.3f & ', resultsTable(1,1:3));
fprintf(f,'& %1.3f ', resultsTable(1,4:6));
fprintf(f,'\\\\\n & & AR-CCE & - & - & %1.3f & & - & - & %1.3f',...
    resultsTable(2,3),resultsTable(2,6));
fprintf(f,'\\\\\n & & FMTU &');
fprintf(f,' %1.3f & ', resultsTable(3,1:3));
fprintf(f,'& %1.3f ', resultsTable(3,4:6));
fprintf(f,'\\\\\n \\cline{2-10}\n');

fprintf(f,' & $\\Vert\\pi\\Vert_2=0.1$ & CCE &');
fprintf(f,' %1.3f & ', resultsTable(4,1:3));
fprintf(f,'& %1.3f ', resultsTable(4,4:6));
fprintf(f,'\\\\\n & & AR-CCE & - & - & %1.3f & & - & - & %1.3f',...
    resultsTable(5,3),resultsTable(5,6));
fprintf(f,'\\\\\n & & FMTU &');
fprintf(f,' %1.3f & ', resultsTable(6,1:3));
fprintf(f,'& %1.3f ', resultsTable(6,4:6));

fprintf(f,'\n');

fclose(f);






