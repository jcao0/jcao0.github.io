function [beta0_hat,testCL,se_cl,testCL_alt,t_stat] = test_cl(method,...
    data,group,alt_vec)

switch lower(method)
    case 'ols'

        D = data.D;
        X = data.X;
        Y = data.Y;
        
        X_mat = [D X];
        betaHat_ols = X_mat\Y;
        resid = Y-X_mat*betaHat_ols;
        iXX = inv(X_mat'*X_mat);
        beta0_hat = betaHat_ols(1); % OLS estimate

        sctmp = cluster_se(X_mat,resid,iXX,group);
        se_cl = sctmp(1); % clustered standard error

        t_stat = (beta0_hat-0)/se_cl;
        testCL = (abs(t_stat) > tinv(.975,max(group)-...
            1))*1; % test against null
        
        testCL_alt = (abs((beta0_hat-alt_vec)/se_cl) > tinv(.975,max(...
            group)-1))*1; % test against alternatives
        
    case 'iv'
        
        D = data.D;
        X = data.X;
        Y = data.Y;
        Z = data.Z;
        
        X_mat = [D X];
        Z_mat = [Z X];

        beta_iv = (Z_mat'*X_mat)\(Z_mat'*Y);
        beta0_hat = beta_iv(1);
        resid = Y-X_mat*beta_iv;
        iZX = inv(Z_mat'*X_mat);
        sctmp = cluster_se(Z_mat,resid,iZX,group);
        se_cl = sctmp(1); 

        beta0_null = 0; % null hypothesis
        t_stat = (beta0_hat-beta0_null)/se_cl;
        testCL = (abs(t_stat) > tinv(.975,max(...
        group)-1))*1; % test restuls
        
        testCL_alt = (abs((beta0_hat-alt_vec)/se_cl) > tinv(.975,max(...
                group)-1))*1; % test against alternatives
end