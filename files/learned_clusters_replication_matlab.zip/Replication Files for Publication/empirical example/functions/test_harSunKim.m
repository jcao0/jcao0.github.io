function [p_value] = test_harSunKim(method,data,Xcoord,Ycoord)

switch lower(method)
    case 'ols'
        
        D = data.D;
        X = data.X;
        Y = data.Y;
        n = length(D);

        M2 = eye(n)-X*((X'*X)\X');
        MD = M2*D;
        MY = M2*Y;
        ydep = MY;
        x_reg = MD;
        R = 1;
        r = 0;
        
        p_value = main_web(ydep,x_reg,Xcoord,...
            Ycoord,R,r);
        
    case 'iv'
        
        D = data.D;
        X = data.X;
        Y = data.Y;
        Z = data.Z;
        X_mat = [D X];
        Z_mat = [Z X];
        
        p = size(X,2)-1;
        R = [1 zeros(1,p+1)];
        r = 0;
        
        p_value = main_web_iv(Y,X_mat,Z_mat,Xcoord,Ycoord,R,r);

end


