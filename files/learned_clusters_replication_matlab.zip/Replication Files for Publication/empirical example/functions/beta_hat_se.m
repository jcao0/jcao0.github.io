% This function calculates the standard deviation of OLS estimator (or mean
% absolute deviation of IV estimator) using the full sample. The output is
% used to benchmark the interesting alternatives. 
function [se] = beta_hat_se(method,config)

% set-up
alternative = 0;
S = 1000;
beta_hat_vec = zeros(S,1);

switch lower(method)
    case 'ols'
        for i_s = 1 : S
            data = DGP(method,config,alternative);
            D = data.D;
            X = data.X;
            Y = data.Y;
            X_mat = [D X];
            betaHat_ols = X_mat\Y; % ols estimate
            beta_hat_vec(i_s) = betaHat_ols(1);
        end
        
        se = std(beta_hat_vec);
        
    case 'iv'
        for i_s = 1 : S
            data = DGP(method,config,alternative);
            D = data.D;
            X = data.X;
            Y = data.Y;
            Z = data.Z;
            X_mat = [D X];
            Z_mat = [Z X];
            betaHat_iv = (Z_mat'*X_mat)\(Z_mat'*Y); % iv estimate
            beta_hat_vec(i_s) = betaHat_iv(1);
        end
        
        se = mean(abs(beta_hat_vec-median(beta_hat_vec)));
        
end

end