function [test_result,p_value] = CRS(beta0_g,d,alpha_sig)

beta0_hat = mean(beta0_g);

m_dBin = size(d,1);
beta0_sample = mean(d.*repmat(beta0_g',m_dBin,1),2);

p_value = mean(abs(beta0_sample)>=abs(beta0_hat));
test_result = 1*(p_value<alpha_sig);