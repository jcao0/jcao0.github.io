% This function calculate frequencies of being chosen as the "optimal"
% inference procedure.
function [output] = output_clustering_optimal_rate(n_sim)

cd ../result
method_vec = zeros(1,n_sim);

i_real = 0;
for i_sim = 1 : n_sim
    s = ['results',num2str(i_sim),'.mat'];
    if exist(s, 'file') == 2
        i_real = i_real+1;
        load(s)
        method_vec(i_real) = output_OPTI.method;    
    end
end
method_vec(i_real+1:end) = [];
cd ../output

output = mean(repmat(method_vec,3,1)==repmat([1;2;3],1,i_real),2);





