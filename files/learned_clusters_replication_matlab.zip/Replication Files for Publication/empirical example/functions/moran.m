function f = moran(W,Y)

f = (Y'*W*Y)/sqrt((var(Y)^2)*(trace(W*W)+trace(W*W')));

