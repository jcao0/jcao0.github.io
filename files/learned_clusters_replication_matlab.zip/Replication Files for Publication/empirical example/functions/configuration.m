function config = configuration(setting)

if lower(setting) == "sar"
    spatial_model = 'sar';
    if lower(setting) == "lowspatial"
        spatial_corr = .13; % SAR: .13 for low corr and .14 for high corr
    else
        spatial_corr = .14;
    end
else
    spatial_model = 'dampedcos'; % {'dampedcos','sar'} 
    if lower(setting) == "lowspatial"
        spatial_corr = .5; % Damped Cos: 0.5 for low corr and 3 for high corr
    else
        spatial_corr = 3;
    end
end

if lower(setting) == "nonstat"
    stationary = 0;
else
    stationary = 1;
end

if lower(setting) == "discrete"
    discrete = 1;
elseif lower(setting) == "empirical"
    discrete = 1;
else
    discrete = 0;
end

if lower(setting) == "smalln"
    N = 205;
elseif lower(setting) == "empirical"
    N = 205;
else
    N = 820;
end

if lower(setting) == "lowd"
    p = 1;
else
    p = 10;
end

if lower(setting) == "highendo"
    rho_endo = .9;
else
    rho_endo = .6;
end

if lower(setting) == "highrelev"
    pi_z = 1;
else
    pi_z = .5;
end

serial_corr = 1;
T = 2; % number of time series
n = N*T;
criterion = @(t1,t2)0.75*((t1>.05).*(t1-.05)+(t1>.06).*...
    (10*(t1-.06)).^2)+.25*t2; % T1-T2 tradeoff criterion

% output
config.spatial_model = spatial_model;
config.spatial_corr = spatial_corr;
config.serial_corr = serial_corr;
config.stationary = stationary;
config.discrete = discrete;
config.criterion = criterion;
config.rho_endo = rho_endo;
config.pi_z = pi_z;
config.N = N;
config.p = p;
config.T = T;
config.n = n;






