function [SigmaHat] = dampedCos(U,disMat,timeMat)
% This function taks a vector of U (usually estimated), a distance
% matrix, and a time gap matrix, and performs QML to estimate covariance 
% matrix.  

% Sigma_func = @(alpha)alpha(1)*exp(-disMat/alpha(2)-timeMat/alpha(3)...
%     ).*cos(alpha(4)*(-disMat/alpha(2)-timeMat/alpha(3)));
% Q = @(alpha).5*logdet(2*pi*Sigma_func(alpha))+.5*U'*...
%     (Sigma_func(alpha)\U);
% 
% options = optimoptions('fmincon','display','none');
% alpha_init = [1;1;1;0];
% alphaHat = fmincon(Q,alpha_init,[],[],[],[],[.01;.01;.01;0],...
%     [10;10;10;10],[],options);
% 
% SigmaHat = Sigma_func(alphaHat); % estimated covariance matrix


%% first estimate variance
n = length(U);
sigma2 = var(U);

Sigma_func = @(alpha)sigma2*eye(n)+alpha(1)*exp(-disMat/alpha(2)-...
    timeMat/alpha(3)).*cos(alpha(4)*(-disMat/alpha(2)-timeMat/...
    alpha(3)))-diag(diag(alpha(1)*exp(-disMat/alpha(2)-timeMat/alpha(3)...
    ).*cos(alpha(4)*(-disMat/alpha(2)-timeMat/alpha(3)))));

Q = @(alpha).5*logdet(2*pi*Sigma_func(alpha))+.5*U'*...
    (Sigma_func(alpha)\U);

options = optimoptions('fmincon','display','none');
alpha_init = [.001;1;1;0];

alphaHat = fmincon(Q,alpha_init,[],[],[],[],[0;.01;.01;-10],...
    [10;10;10;10],[],options);

SigmaHat = Sigma_func(alphaHat); % estimated covariance matrix

SigmaHat = topdm(SigmaHat); % repair non-psd covariance matrix








