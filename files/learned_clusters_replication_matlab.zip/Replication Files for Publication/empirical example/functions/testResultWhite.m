function testWhite = testResultWhite(X,Y)

[n,p] = size(X);

betaHat_ols = X\Y;
resid = Y-X*betaHat_ols;
temp = (X.*repmat(resid,1,p))/(X'*X);
asymVar = n*(temp'*temp);
stmp = sqrt(diag(asymVar)/n);
thetaHat_ols = betaHat_ols(1); % OLS estimate
se_w = stmp(1); % white se

testWhite = (abs(thetaHat_ols/se_w)>1.96)*1;
