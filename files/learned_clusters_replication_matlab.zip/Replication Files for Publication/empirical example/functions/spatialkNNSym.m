function W = spatialkNNSym(D,k)

n = size(D,1);
W = zeros(size(D));

for ii = 1:n
    dii = sort(D(ii,:));
    kii = D(ii,:) <= dii(k+1) & D(ii,:) > 0;
    W(ii,kii) = 1;
end
W = max(W,W');