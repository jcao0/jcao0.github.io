function [Sigma_new,ind_new,group_new] = grouped_cov(Sigma,group)
% This function transforms the covariance matrix into one that follows the
% orderings in the group vector

n = size(Sigma,2);

Ig = unique(group);
ind = (1:n)';

ind_new = [];
group_new = [];
for i = min(Ig) : max(Ig)
    ind_new = [ind_new; ind(group == i)];
    group_new = [group_new; i*ones(sum(group==i),1)];
end

Sigma_new = zeros(n);
for i = 1 : n
    for j = 1 : n
        Sigma_new(i,j) = Sigma(ind_new(i),ind_new(j));
    end
end





