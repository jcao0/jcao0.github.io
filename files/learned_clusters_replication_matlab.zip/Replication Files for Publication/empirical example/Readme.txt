README file

Code for Section 3 in Cao, Hansen, Kozbur and Villacorta, (2021) " Inference for Dependent Data with Learned Clusters"
We run the code in Matlab version 2017a


Empirical Application
To replicate Table 1 and Table 2 in Section 3 of the paper run the code main_empirical_application_2021.m 

Data
The data is from Condra et al (2018) and is imported from the file ElectionViolanceTable.csv

The code main_empirical_application_2021.m uses functions located in the file "functions"  












 