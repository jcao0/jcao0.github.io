
clear
    
%% main text
run('../sim1_ols_small_baseline/code/main.m')
run('../sim2_ols_small_sar/code/main.m')
run('../sim3_iv_small_baseline/code/main.m')
run('../sim4_iv_small_sar/code/main.m')

%% supplement
run('../sim5_ols_large_baseline/code/main.m')
run('../sim6_ols_large_sar/code/main.m')
run('../sim7_iv_large_baseline/code/main.m')
run('../sim8_iv_large_sar/code/main.m')


