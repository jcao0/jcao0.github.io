% This script cleans the data and generates all variables needed.
% Data is from Abadie, Diamond, and Hainmueller (2010).

[data,states,~] = xlsread('cigs.xls');
state = unique(states(2:end,1));
year = unique(data(:,1));
N = length(state);
T = 1989-1970;
S = length(year)-T;
cig = reshape(data(:,2),T+S,N);
cig = cig'; 
CA = cig(3,:);
cig(3,:) = [];
cig = [CA;cig];
Y = cig; % outcome matrix

% indicators of all uints assumed to be potentially affected by the policy
ind = [1,0,0,0,1,1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,1,1,1,0,0,0,1,0,...
    0,0,0,1,1,0,0,0,0]';
A = eye(N);
A(:,ind == 0) = []; % matrix of spillover exposure

% test
ind = [1;zeros(38,1)];
A = eye(N);
A(:,ind == 0) = []; % matrix of spillover exposure

