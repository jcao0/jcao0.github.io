
clear
addpath('functions');
alpha_sig = .05;


%% DATA INPUT

data_input

% Y: N-by-(T+S) outcome matrix with first row being treated unit
% N: number of units
% T: number of pre-treatment time periods
% S: number of post-treatment time periods
% A: matrix of spillover exposure


%% ESTIMATION

Y_pre = Y(:,1:T);
Y_post = Y(:,T+1:end);

% synthetic control weights and intercepts for all units
[a_hat,B_hat] = scm_batch(Y_pre);

M_hat = (eye(N)-B_hat)'*(eye(N)-B_hat); % M=(I-B)'(I-B)
synthetic_control = a_hat(1)+B_hat(1,:)*Y;
alpha1_hat_vec = zeros(1,S); % treatment effect estimator
for s = 1 : S
    Y_Ts = Y(:,T+s);
    gamma_hat = (A'*M_hat*A)\(A'*(eye(N)-B_hat)'*((eye(N)-B_hat)*...
        Y_Ts-a_hat));
    alpha_hat = A*gamma_hat;
    alpha1_hat_vec(s) = alpha_hat(1);
    synthetic_control(T+s) = Y(1,T+s)-alpha1_hat_vec(s);
end



%% INFERENCE - TREATMENT EFFECTS
% test for treatment effect

C = [1 zeros(1,N-1)]; 

p_value_vec = zeros(1,S);
lb_vec = zeros(1,S);
ub_vec = zeros(1,S);

for s = 1 : S

    [p_value,lb,ub] = sp_andrews_te(Y_pre,cig(:,T+s),A,C,alpha_sig);
    p_value_vec(s) = p_value;
    lb_vec(s) = lb;
    ub_vec(s) = ub;
    
end


%% INFERENCE - SPILLOVER EFFECTS
% test for whether there is spillover at each post-treatment period

spillover_test = zeros(1,S);

for s = 1 : S

    C = [zeros(N-1,1) eye(N-1)];
    d = zeros(N-1,1);

    spillover_test(s) = sp_andrews(Y_pre,cig(:,T+s),A,C,d,alpha_sig);

end


%% OUTPUT TABLE

output_mat = zeros(S,5); % output: [time,estimate,p-value,lb,ub]
output_mat(:,1) = (1:S)';
output_mat(:,2) = alpha1_hat_vec;
output_mat(:,3) = p_value_vec;
output_mat(:,4) = lb_vec;
output_mat(:,5) = ub_vec;

fprintf('\n            ####### OUTPUT TABLE #######\n')
fprintf('Time    TE estimate    p-value            CI\n')
for s = 1 : S
    fprintf('%2d%15.4f%12.4f     [%8.4f,%8.4f]\n',output_mat(s,:))
end


%% PLOT - ACTUAL VS COUNTERFACTUAL OUTCOMES

figure

p = plot(1:(T+S),synthetic_control,1:(T+S),Y(1,:));
xline(T+.5,'--'); % treatment time: between T and T+1

p(1).LineWidth = 1.5;
p(2).LineWidth = 1.5;
lgd = legend('counter-factual','actual');
lgd.FontSize = 14;
xlabel('time','FontSize', 16)
ylabel('outcome','FontSize', 16)
xlim([.5,T+S+.5])


%% PLOT - RESIDUALS AND TREATMENT EFFECT ESTIMATES

figure

hold on 

% gray area indicating existence of spillover effects  
y_max = max(abs(min(lb_vec)),abs(max(ub_vec)))*1.2;
basevalue = -y_max;
for s = 1 : S
    if spillover_test(s) == 1
        area([T+s-.5 T+s+.5], [y_max y_max],basevalue,...
            'LineStyle','none','FaceColor',[.8 .8 .8]);
    end
end

% residuals of pre-treatment fitting
p = plot(1:(T+1),Y(1,1:(T+1))-synthetic_control(1:(T+1)));

% treatment effect estimates
p_e = errorbar((T+1):(T+S),Y(1,(T+1):(T+S))-synthetic_control...
    ((T+1):(T+S)),alpha1_hat_vec-lb_vec,ub_vec-alpha1_hat_vec);

hold off

xline(T+.5,'--'); % treatment time
yline(0,'--');
p.LineWidth = 1.5;
p.Color = '[     0    0.4470    0.7410]';
p_e.LineWidth = 1.5;
p_e.Color = '[     0    0.4470    0.7410]';
xlabel('time','FontSize', 16)
ylabel('residual/treatment effect estimate','FontSize', 16)
xlim([.5,T+S+.5])
ylim([-y_max,y_max])



