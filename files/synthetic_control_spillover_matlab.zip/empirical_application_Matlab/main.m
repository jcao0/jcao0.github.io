
clear
addpath('functions');
alpha_sig = .05;


%% DATA INPUT

run('code/data_input.m')

% Y: N-by-(T+S) outcome matrix with first row being treated unit
% N: number of units
% T: number of pre-treatment time periods
% S: number of post-treatment time periods
% A: matrix of spillover exposure


%% ESTIMATION

Y_pre = Y(:,1:T);
Y_post = Y(:,T+1:end);

% synthetic control weights and intercepts for all units
[a_hat,B_hat] = scm_batch(Y_pre);
synthetic_control_scm = a_hat(1)+B_hat(1,:)*Y; % vanilla SCM

M_hat = (eye(N)-B_hat)'*(eye(N)-B_hat); % M=(I-B)'(I-B)
synthetic_control_sp = a_hat(1)+B_hat(1,:)*Y_pre;
alpha1_hat_vec = zeros(1,S); % treatment effect estimator
for s = 1 : S
    Y_Ts = Y(:,T+s);
    gamma_hat = (A'*M_hat*A)\(A'*(eye(N)-B_hat)'*((eye(N)-B_hat)*...
        Y_Ts-a_hat));
    alpha_hat = A*gamma_hat;
    alpha1_hat_vec(s) = alpha_hat(1);
    synthetic_control_sp(T+s) = Y(1,T+s)-alpha1_hat_vec(s);
end


%% INFERENCE - TREATMENT EFFECTS
% test for treatment effect

C = [1 zeros(1,N-1)]; 

p_value_vec = zeros(1,S);
lb_vec = zeros(1,S);
ub_vec = zeros(1,S);

for s = 1 : S

    [p_value,lb,ub] = sp_andrews_te(Y_pre,cig(:,T+s),A,C,alpha_sig);
    p_value_vec(s) = p_value;
    lb_vec(s) = lb;
    ub_vec(s) = ub;
    
end


%% INFERENCE - SPILLOVER EFFECTS
% test for whether there is spillover at each post-treatment period

spillover_test = zeros(1,S);

for s = 1 : S

    C = [zeros(N-1,1) eye(N-1)];
    d = zeros(N-1,1);

    spillover_test(s) = sp_andrews(Y_pre,cig(:,T+s),A,C,d,alpha_sig);

end


%% OUTPUT TABLE

output_mat = zeros(S,5); % output: [time,estimate,p-value,lb,ub]
output_mat(:,1) = (1:S)';
output_mat(:,2) = alpha1_hat_vec;
output_mat(:,3) = p_value_vec;
output_mat(:,4) = lb_vec;
output_mat(:,5) = ub_vec;

fprintf('\n            ####### OUTPUT TABLE #######\n')
fprintf('Time    TE estimate    p-value            CI\n')
for s = 1 : S
    fprintf('%2d%15.4f%12.4f     [%8.4f,%8.4f]\n',output_mat(s,:))
end


%% PLOT - ACTUAL VS COUNTERFACTUAL OUTCOMES

f1 = figure(1);

p = plot(year,Y(1,:),'-.',year,synthetic_control_scm,'--',...
    year,synthetic_control_sp,...
    [1988,1988],[35,135],'--k');
p(1).LineWidth = 1.5;
p(2).LineWidth = 1.5;
p(3).LineWidth = 1.5;
p(1).Color = [ 0.9290    0.6940    0.1250];
p(2).Color = [ 0.8500    0.3250    0.0980];
p(3).Color = [   0    0.4470    0.7410];
ylim([35,135])
lgd = legend('California','Synthetic California',...
    'SP synthetic California','Location','southwest');
lgd.FontSize = 16;
x1 = 1975;
y1 = 70;
txt1 = 'Passage of Proposition 99 \rightarrow';
text(x1,y1,txt1, 'FontSize', 16,'FontName', 'Times New Roman')
set(gca, 'FontName', 'Times New Roman')
xlabel('year','FontSize', 16,'FontName', 'Times New Roman');
ylabel('per-capita cigarette sales (in packs)',...
    'FontSize', 16,'FontName', 'Times New Roman');

filePath = sprintf('output/california_vs_synthetic.pdf');
saveas(f1,filePath);
% close(f1)


%% PLOT - RESIDUALS AND TREATMENT EFFECT ESTIMATES

f2 = figure(2);

basevalue = -25;
h = area([1990-.5 year(end)], [25 25],basevalue,'LineStyle','none');
h.FaceColor = [.8 .8 .8];

hold on 
p = plot(year,Y(1,:)-synthetic_control_scm,'--',year,...
    Y(1,:)-synthetic_control_sp,[1988,1988],[-30,30],'--k',...
    [year(1),year(end)],[0,0],'--k');
p(1).LineWidth = 1.5;
p(2).LineWidth = 1.5;
p(1).Color = '[0.8500 0.3250 0.0980]';
p(2).Color = '[     0    0.4470    0.7410]';
ylim([-25,25])
% hold on
p3 = errorbar(year(T+1:end),Y(1,T+1:end)-synthetic_control_sp(T+1:end),...
    alpha1_hat_vec-lb_vec,ub_vec-alpha1_hat_vec);
p3.Color = '[     0    0.4470    0.7410]';
hold off
lgd = legend([p(1) p(2)],{'SCM','SP'},'Location','Northwest');
lgd.FontSize = 16;
x1 = 1975;
y1 = -13;
txt1 = 'Passage of Proposition 99 \rightarrow';
text(x1,y1,txt1, 'FontSize', 16,'FontName', 'Times New Roman')
set(gca, 'FontName', 'Times New Roman')
xlabel('year','FontSize', 16,'FontName', 'Times New Roman');
ylabel('per-capita cigarette sales (in packs)',...
    'FontSize', 16,'FontName', 'Times New Roman');

filePath = sprintf('output/treatment_effects.pdf');
saveas(f2,filePath);
% close(f2)

